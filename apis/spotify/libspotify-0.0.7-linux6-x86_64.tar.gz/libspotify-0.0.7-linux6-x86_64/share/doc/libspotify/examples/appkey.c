#error
#error "You need to replace this file with a libspotify API key provided by Spotify. Please see https://developer.spotify.com/en/libspotify/application-key/"
#error
